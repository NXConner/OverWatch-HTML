import { createRouter } from "./router/router.js";
import { createApiClient } from "./api/client.js";
import { createThemeStore } from "./state/theme-store.js";
import { createSessionStore } from "./state/session-store.js";
import { createUiStore } from "./state/ui-store.js";
import { createHudHeader } from "./components/hud-header.js";
import { createHudSidebar } from "./components/hud-sidebar.js";
import { createMobileNav } from "./components/mobile-nav.js";
import { createTelemetryFeed } from "./components/telemetry-feed.js";
import { createCommandPalette } from "./components/command-palette.js";
import { createLoginPage } from "./pages/login-page.js";
import { createDashboardPage } from "./pages/dashboard-page.js";
import { createCasesPage } from "./pages/cases-page.js";
import { createCaseDetailPage } from "./pages/case-detail-page.js";
import { createUploadPage } from "./pages/upload-page.js";
import { createAnalysisPage } from "./pages/analysis-page.js";
import { createEventsPage } from "./pages/events-page.js";
import { createEventsTimelinePage } from "./pages/events-timeline-page.js";
import { createIntelligencePage } from "./pages/intelligence-page.js";
import { createMapPage } from "./pages/map-page.js";
import { createSubjectsPage } from "./pages/subjects-page.js";
import { createAuditPage } from "./pages/audit-page.js";
import { createSettingsPage } from "./pages/settings-page.js";
import { createContactPage } from "./pages/contact-page.js";

const api = createApiClient("/api");
const themeStore = createThemeStore();
const sessionStore = createSessionStore(api);
const uiStore = createUiStore();

const appRoot = document.querySelector("#app");

const routes = [
  { path: "/login", public: true, handler: () => createLoginPage({ sessionStore, router }) },
  { path: "/dashboard", handler: () => createDashboardPage({ api }) },
  { path: "/cases", handler: () => createCasesPage({ api }) },
  { path: "/cases/:id", handler: ({ params }) => createCaseDetailPage({ api, params }) },
  { path: "/upload", handler: () => createUploadPage({ api }) },
  { path: "/analysis", handler: () => createAnalysisPage({ api }) },
  { path: "/events", handler: () => createEventsPage({ api }) },
  { path: "/events/timeline", handler: () => createEventsTimelinePage({ api }) },
  { path: "/intelligence", handler: () => createIntelligencePage({ api }) },
  { path: "/map", handler: () => createMapPage({ api }) },
  { path: "/subjects", handler: () => createSubjectsPage({ api }) },
  { path: "/audit", handler: () => createAuditPage({ api }) },
  { path: "/settings", handler: () => createSettingsPage({ themeStore, sessionStore }) },
  { path: "/contact", public: true, handler: () => createContactPage({ api }) },
];

const router = createRouter({
  routes,
  onRoute: async (match) => {
    const user = sessionStore.getState().user;
    if (!match) {
      router.navigate("/dashboard", { replace: true });
      return;
    }
    if (!match.route.public && !user) {
      router.navigate("/login", { replace: true });
      return;
    }
    await renderRoute(match);
  },
});

async function renderRoute(match) {
  appRoot.innerHTML = "";
  const pathname = window.location.pathname;

  if (match.route.path === "/login") {
    appRoot.appendChild(await match.route.handler(match));
    return;
  }

  const shell = document.createElement("main");
  shell.className = "app-shell";
  const mainColumn = document.createElement("section");
  mainColumn.className = "main-column";

  const sidebar = createHudSidebar();
  sidebar.render(pathname);
  shell.appendChild(sidebar.element);

  const header = createHudHeader({ sessionStore, themeStore, uiStore, router });
  mainColumn.appendChild(header);

  const content = document.createElement("section");
  const node = await match.route.handler(match);
  const telemetry = createTelemetryFeed(api);
  telemetry.start();
  content.appendChild(node);
  content.appendChild(telemetry.element);
  mainColumn.appendChild(content);

  const mobileNav = createMobileNav();
  mobileNav.render(pathname);
  mainColumn.appendChild(mobileNav.element);

  shell.appendChild(mainColumn);
  appRoot.appendChild(shell);
  appRoot.appendChild(createCommandPalette({ uiStore, router }));
}

async function bootstrap() {
  await sessionStore.bootstrap();
  if (window.location.pathname === "/") {
    router.navigate("/dashboard", { replace: true });
  }
  router.start();
}

bootstrap();
