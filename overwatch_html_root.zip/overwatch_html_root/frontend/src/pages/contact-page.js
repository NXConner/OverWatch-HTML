import { createPage } from "./page-utils.js";

export function createContactPage({ api }) {
  const root = createPage("Contact");
  const panel = document.createElement("article");
  panel.className = "panel";
  panel.innerHTML = `
    <h3 class="mono">Contact Form</h3>
    <form id="contact-form" class="grid-2">
      <label class="field">Name<input name="name" required /></label>
      <label class="field">Email<input type="email" name="email" required /></label>
      <label class="field" style="grid-column:1/-1;">Subject<input name="subject" /></label>
      <label class="field" style="grid-column:1/-1;">Message<textarea name="message" required></textarea></label>
      <button class="btn btn-primary" style="width:max-content;">Send</button>
      <span id="contact-status" class="muted"></span>
    </form>
  `;
  root.appendChild(panel);

  panel.querySelector("#contact-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const status = panel.querySelector("#contact-status");
    status.textContent = "Submitting...";
    try {
      const body = Object.fromEntries(new FormData(event.currentTarget).entries());
      await api.post("/contact", body);
      status.textContent = "Submission received.";
      event.currentTarget.reset();
    } catch (error) {
      status.textContent = error.message;
    }
  });

  return root;
}
