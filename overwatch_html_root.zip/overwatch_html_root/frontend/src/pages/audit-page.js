import { createPage, addErrorBox } from "./page-utils.js";

export async function createAuditPage({ api }) {
  const root = createPage("Audit");
  try {
    const data = await api.get("/audit?limit=100");
    const panel = document.createElement("article");
    panel.className = "panel";
    panel.innerHTML = `
      <h3 class="mono">Audit Log</h3>
      <ul class="list">
        ${(data.items || [])
          .map(
            (item) =>
              `<li class="list-item"><strong>${item.action}</strong> <span class="muted">${item.entity || ""}</span><div class="muted">${
                item.createdAt || ""
              }</div></li>`
          )
          .join("")}
      </ul>
    `;
    root.appendChild(panel);
  } catch (error) {
    addErrorBox(root, error.message);
  }
  return root;
}
