import { createPage, addErrorBox } from "./page-utils.js";

export async function createSubjectsPage({ api }) {
  const root = createPage("Subjects");
  const createPanel = document.createElement("article");
  createPanel.className = "panel";
  createPanel.innerHTML = `
    <h3 class="mono">Create Subject</h3>
    <form id="subject-form" class="grid-2">
      <label class="field">Name<input name="name" required /></label>
      <label class="field">Alias<input name="alias" /></label>
      <label class="field">Case<select name="caseId" required></select></label>
      <label class="field" style="grid-column:1/-1;">Description<textarea name="description"></textarea></label>
      <button class="btn btn-primary" style="width:max-content;">Create Subject</button>
      <span id="subject-status" class="muted"></span>
    </form>
  `;
  root.appendChild(createPanel);

  const listPanel = document.createElement("article");
  listPanel.className = "panel";
  root.appendChild(listPanel);

  async function load() {
    const [subjects, cases] = await Promise.all([
      api.get("/subjects?limit=100"),
      api.get("/cases?limit=100"),
    ]);
    createPanel.querySelector("select").innerHTML = (cases.items || [])
      .map((item) => `<option value="${item.id}">${item.caseNumber} - ${item.title}</option>`)
      .join("");
    listPanel.innerHTML = `
      <h3 class="mono">Subject Inventory</h3>
      <ul class="list">
        ${(subjects.items || [])
          .map(
            (s) =>
              `<li class="list-item"><strong>${s.name}</strong> <span class="muted">${
                s.alias || ""
              }</span><div class="muted">${s.case?.caseNumber || ""}</div></li>`
          )
          .join("")}
      </ul>
    `;
  }

  try {
    await load();
  } catch (error) {
    addErrorBox(root, error.message);
  }

  createPanel.querySelector("#subject-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const status = createPanel.querySelector("#subject-status");
    status.textContent = "Saving...";
    try {
      const body = Object.fromEntries(new FormData(event.currentTarget).entries());
      await api.post("/subjects", body);
      status.textContent = "Saved.";
      event.currentTarget.reset();
      await load();
    } catch (error) {
      status.textContent = error.message;
    }
  });

  return root;
}
