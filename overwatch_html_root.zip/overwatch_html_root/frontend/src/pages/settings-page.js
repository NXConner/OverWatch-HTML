import { createPage } from "./page-utils.js";

export function createSettingsPage({ themeStore, sessionStore }) {
  const root = createPage("Settings");
  const panel = document.createElement("article");
  panel.className = "panel";

  function render() {
    const theme = themeStore.getState();
    const session = sessionStore.getState();
    panel.innerHTML = `
      <h3 class="mono">UI + Session Settings</h3>
      <p class="muted">Current theme: ${theme.mode}</p>
      <button class="btn" data-action="toggle-theme">Toggle Theme</button>
      <hr style="border-color:var(--border);margin:12px 0;" />
      <p class="muted">User: ${session.user?.email || "none"}</p>
    `;
  }

  panel.addEventListener("click", (event) => {
    if (event.target.closest("[data-action='toggle-theme']")) {
      themeStore.toggleTheme();
    }
  });

  themeStore.subscribe(render);
  sessionStore.subscribe(render);
  render();
  root.appendChild(panel);
  return root;
}
