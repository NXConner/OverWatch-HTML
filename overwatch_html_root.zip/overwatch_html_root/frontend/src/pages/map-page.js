import { createPage, addErrorBox, addJsonPanel } from "./page-utils.js";

export async function createMapPage({ api }) {
  const root = createPage("Map");
  const panel = document.createElement("article");
  panel.className = "panel";
  panel.innerHTML = `
    <h3 class="mono">Map Data Query</h3>
    <form id="map-form" class="grid-2">
      <label class="field">Case<select name="caseId"></select></label>
      <button class="btn btn-primary" style="width:max-content;">Load Map Data</button>
    </form>
  `;
  root.appendChild(panel);
  const output = document.createElement("section");
  root.appendChild(output);

  try {
    const data = await api.get("/cases?limit=100");
    panel.querySelector("select").innerHTML = (data.items || [])
      .map((item) => `<option value="${item.id}">${item.caseNumber} - ${item.title}</option>`)
      .join("");
  } catch (error) {
    addErrorBox(root, error.message);
  }

  panel.querySelector("#map-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    output.innerHTML = "";
    const caseId = new FormData(event.currentTarget).get("caseId");
    try {
      const points = await api.get(`/map/points?caseId=${encodeURIComponent(caseId)}`);
      const heatmap = await api.get(`/map/heatmap?caseId=${encodeURIComponent(caseId)}`);
      const data = { points, heatmap };
      addJsonPanel(output, "Map Markers", data);
    } catch (error) {
      addErrorBox(output, error.message);
    }
  });

  return root;
}
